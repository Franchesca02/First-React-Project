# Simple React Signup Form With Validation

## Steps for excecution :

 1. Clone the repo : git clone https://github.com/abhishek305/simple-react-signup-form-with-validation.git
 2. Open the cloned repo in a code editor 
 3. Fire up the terminal in the root directory and provide the command npm install
 4. Then give the command npm start
