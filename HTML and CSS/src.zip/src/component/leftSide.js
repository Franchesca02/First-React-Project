import React from "react";
import { NavLink } from "react-router-dom";
import Item from "../files/parfait.jpg";
// import Girl from "../files/girl.jpeg";

function Left() {
  return (
    <div className="left">
      <div className="side-logo height">
          <div className="overlay"></div>
        <NavLink to="/" className="back"> Back to store</NavLink>
      </div>
      <div className="order-summary height">
          <h6>Order Summary</h6>
          <div className="item-cards">
            <div className="item">
                <div className="item-image">
                    <img src={Item} alt="Card Image"/>                </div>
            <div className="item-details">
                <p>Parfait</p>
                <p>#2000</p>
                <p>Qty: 2</p>
            </div>
            </div>
            <div className="item">
                <div className="item-image">
                    <img src={Item} alt="Card Image"/>                </div>
            <div className="item-details">
                <p>Parfait</p>
                <p>#2000</p>
                <p>Qty: 2</p>
            </div>
            </div>
          </div>
          <div className="item-cards total">
            <h6>ADD</h6>
            <h6>459</h6>
          </div>
      </div>
    </div>
  );
}

export default Left;
