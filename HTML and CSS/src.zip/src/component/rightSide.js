import React from "react"
import { NavLink } from "react-router-dom";
import Worker from '../files/girl.jpeg';

function Right() {
    return (
        <div className="right">
            <h4 className="what">What Do You Do?</h4>
            <div className="organisation">
                <div className="one">
                    <img src={Worker} alt="A working man" />
                    <p>Paid Employment</p>
                </div>
                <div className="two">
                    <img src={Worker} alt="a working lady" />
                    <p>Self employed/Freelance</p>
                </div>
                <div className="three">
                    <img src={Worker} alt="A bulding" />
                    <p>Corporate organisation</p>
                </div>
            </div>
            <div className="payment">
                <div className="pay-range">
                    <h6>How Much Do You Get Paid Monthly?</h6>
                    <div className="money">
                       <input type="text"/>  
                    </div>
                </div>
                <div className="salary">
                    <h6>When is Your Next Salary Date?</h6>
                    <div className="salary-date"></div>
                    <select >
                        <option>Select next salary date</option>
                        <option>boy</option>
                        <option>boy</option>
                    </select>
                    
                    
                </div>
                <div className="loan">
                    <h6>Do you Have an Existing Loan?</h6>
                    <div className="double-div">
                        <div><input  type="radio"/> <label>Yes</label></div>|    <div><input  type="radio"/> <label>No</label></div> 
                    </div>

                </div>
            </div>
            <button><NavLink to="/payment">Continue</NavLink></button>
        </div>

    );
}

export default Right;
