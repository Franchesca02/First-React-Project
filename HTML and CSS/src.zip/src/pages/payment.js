import Left from "../component/leftSide";
import React from 'react';

function Payment() {
  return (
    <div className="home">
     <Left/>
    </div>
  );
}

export default Payment;