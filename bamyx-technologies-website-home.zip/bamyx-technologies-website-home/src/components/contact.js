import React from 'react';

function Contact() {
    return (
        <div>
<p>You canreach us via our mobile number below:</p>
        </div>
    );
}
export default Contact;