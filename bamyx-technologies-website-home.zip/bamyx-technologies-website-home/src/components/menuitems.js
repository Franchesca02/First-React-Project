export const MenuItems = [
    {
        title: 'Home',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'About Us',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Contact Us',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Our Services',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Blogs',
        url: '#',
        cName: 'nav-links-mobile'
    }

]