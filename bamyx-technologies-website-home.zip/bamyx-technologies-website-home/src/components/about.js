import React from 'react';

function About() {
    return (
        <div>
<p>We are a software engineering company</p>
        </div>
    );
}
export default About;