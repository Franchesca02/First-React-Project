import React from 'react';

function Blogs() {
    return (
        <div>
<p>Welcome to our blog</p>
        </div>
    );
}
export default Blogs;