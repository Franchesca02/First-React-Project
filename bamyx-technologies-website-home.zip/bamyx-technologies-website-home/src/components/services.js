import React from 'react';

function Services() {
    return (
        <div>
<p>We offer a wide range of services</p>
        </div>
    );
}
export default Services;